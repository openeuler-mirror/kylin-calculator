#include "widgetstyle.h"

int WidgetStyle::themeColor = 0;
