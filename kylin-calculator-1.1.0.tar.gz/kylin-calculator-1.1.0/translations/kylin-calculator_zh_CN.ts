<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Calc</name>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="85"/>
        <source>The expression is empty!</source>
        <translation>表达式为空!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="106"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="121"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="126"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="153"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="180"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="247"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="272"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="298"/>
        <source>Expression error!</source>
        <translation>表达式错误!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="116"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="140"/>
        <source>Missing left parenthesis!</source>
        <translation>缺少左括号!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="207"/>
        <source>The value is too large!</source>
        <translation>数值过大!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="219"/>
        <source>Miss operand!</source>
        <translation>缺少操作数!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="328"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="386"/>
        <source>Operator undefined!</source>
        <translation>未定义操作符!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="350"/>
        <source>Divisor cannot be 0!</source>
        <translation>除数不能为0!</translation>
    </message>
    <message>
        <location filename="../calc_programmer/calc/calc.cpp" line="370"/>
        <location filename="../calc_programmer/calc/calc.cpp" line="378"/>
        <source>Right operand error!</source>
        <translation>右操作数错误!</translation>
    </message>
    <message>
        <source>The shifted right operand is negative!</source>
        <translation type="vanished">移位操作右值不能为负数!</translation>
    </message>
</context>
<context>
    <name>FuncList</name>
    <message>
        <location filename="../src/funclist.cpp" line="42"/>
        <source>Calculator</source>
        <translation>计算器</translation>
    </message>
    <message>
        <location filename="../src/funclist.cpp" line="47"/>
        <source>standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../src/funclist.cpp" line="47"/>
        <source>scientific</source>
        <translation>科学</translation>
    </message>
    <message>
        <location filename="../src/funclist.cpp" line="63"/>
        <source>Unit converter</source>
        <translation>换算器</translation>
    </message>
    <message>
        <location filename="../src/funclist.cpp" line="69"/>
        <source>exchange rate</source>
        <translation>汇率</translation>
    </message>
</context>
<context>
    <name>IntelModeList</name>
    <message>
        <location filename="../src/basicbutton.cpp" line="137"/>
        <source>standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../src/basicbutton.cpp" line="140"/>
        <source>scientific</source>
        <translation>科学</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="252"/>
        <source>Calculator</source>
        <translation>计算器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1121"/>
        <location filename="../src/mainwindow.cpp" line="1299"/>
        <location filename="../src/mainwindow.cpp" line="1315"/>
        <source>standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1297"/>
        <source>calculator</source>
        <translation>计算器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="280"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="281"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>input too long</source>
        <translation>输入过长</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="45"/>
        <location filename="../src/mainwindow.cpp" line="1299"/>
        <location filename="../src/mainwindow.cpp" line="1320"/>
        <source>scientific</source>
        <translation>科学</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1334"/>
        <source>exchange rate</source>
        <translation>汇率</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="871"/>
        <location filename="../src/mainwindow.cpp" line="875"/>
        <source>Error!</source>
        <translation>错误!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <source>Input error!</source>
        <translation>输入错误!</translation>
    </message>
</context>
<context>
    <name>ProgramDisplay</name>
    <message>
        <location filename="../src/programmer/programdisplay.cpp" line="56"/>
        <location filename="../src/programmer/programdisplay.cpp" line="79"/>
        <source>input too long!</source>
        <translation>输入过长!</translation>
    </message>
</context>
<context>
    <name>ProgramModel</name>
    <message>
        <location filename="../src/programmer/programmodel.cpp" line="239"/>
        <location filename="../src/programmer/programmodel.cpp" line="314"/>
        <source>Input error!</source>
        <translation>输入错误!</translation>
    </message>
    <message>
        <location filename="../src/programmer/programmodel.cpp" line="401"/>
        <source>ShowBinary</source>
        <translation>显示二进制</translation>
    </message>
    <message>
        <source>DisplayBinary</source>
        <translation type="vanished">显示二进制</translation>
    </message>
    <message>
        <location filename="../src/programmer/programmodel.cpp" line="407"/>
        <source>HideBinary</source>
        <translation>隐藏二进制</translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <source>FuncList</source>
        <translation type="vanished">功能列表</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="262"/>
        <source>Standard</source>
        <translation>计算器—标准</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="263"/>
        <source>Scientific</source>
        <translation>计算器—科学</translation>
    </message>
    <message>
        <source>standard </source>
        <translation type="vanished">标准 </translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="58"/>
        <location filename="../src/titlebar.cpp" line="69"/>
        <location filename="../src/titlebar.cpp" line="230"/>
        <source>standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="59"/>
        <location filename="../src/titlebar.cpp" line="242"/>
        <source>scientific</source>
        <translation>科学</translation>
    </message>
    <message>
        <source>scientific </source>
        <translation type="vanished">科学 </translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="264"/>
        <source>Exchange Rate</source>
        <translation>计算器—汇率</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="265"/>
        <source>Programmer</source>
        <translation>计算器—程序员</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="290"/>
        <source>StayTop</source>
        <translation>置顶</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="291"/>
        <source>Minimize</source>
        <translation>最小化</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="292"/>
        <source>Maximize</source>
        <translation>最大化</translation>
    </message>
    <message>
        <location filename="../src/titlebar.cpp" line="293"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>ToolBar</name>
    <message>
        <source>DisplayBinary</source>
        <translation type="vanished">显示二进制</translation>
    </message>
    <message>
        <location filename="../src/programmer/toolbar.cpp" line="55"/>
        <location filename="../src/programmer/toolbar.cpp" line="217"/>
        <location filename="../src/programmer/toolbar.cpp" line="220"/>
        <source>ShowBinary</source>
        <translation>显示二进制</translation>
    </message>
    <message>
        <location filename="../src/programmer/toolbar.cpp" line="218"/>
        <location filename="../src/programmer/toolbar.cpp" line="219"/>
        <source>HideBinary</source>
        <translation>隐藏二进制</translation>
    </message>
</context>
<context>
    <name>ToolModelOutput</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="76"/>
        <source>Rate update</source>
        <translation>汇率更新</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="91"/>
        <source>Chinese Yuan</source>
        <translation>人民币</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="99"/>
        <source>US Dollar</source>
        <translation>美元</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="580"/>
        <source>Error!</source>
        <translation>错误!</translation>
    </message>
</context>
<context>
    <name>UnitListWidget</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="1191"/>
        <source>currency</source>
        <translation>货币</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1197"/>
        <source>cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">搜索</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="44"/>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="56"/>
        <location filename="../src/menumodule/menumodule.cpp" line="165"/>
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="58"/>
        <location filename="../src/menumodule/menumodule.cpp" line="168"/>
        <source>Scientific</source>
        <translation>科学</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="60"/>
        <location filename="../src/menumodule/menumodule.cpp" line="171"/>
        <source>Exchange Rate</source>
        <translation>汇率</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="62"/>
        <location filename="../src/menumodule/menumodule.cpp" line="174"/>
        <source>Programmer</source>
        <translation>程序员</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="68"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="70"/>
        <location filename="../src/menumodule/menumodule.cpp" line="162"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="72"/>
        <location filename="../src/menumodule/menumodule.cpp" line="159"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="74"/>
        <location filename="../src/menumodule/menumodule.cpp" line="156"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="90"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="94"/>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="98"/>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="314"/>
        <source>Version: </source>
        <translation>版本号: </translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="318"/>
        <source>Calculator is a lightweight calculator based on Qt5, which provides standard calculation, scientific calculation and exchange rate conversion.</source>
        <translation>计算器是一款基于qt5开发的轻量级计算器，提供标准计算，科学计算和汇率换算。</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.cpp" line="400"/>
        <location filename="../src/menumodule/menumodule.cpp" line="418"/>
        <source>Service &amp; Support: </source>
        <translation>服务与支持团队：</translation>
    </message>
    <message>
        <source>Support: support@kylinos.cn</source>
        <translation type="vanished">支持：support@kylinos.cn</translation>
    </message>
    <message>
        <location filename="../src/menumodule/menumodule.h" line="67"/>
        <source>Calculator</source>
        <translation>计算器</translation>
    </message>
</context>
</TS>
