#!/bin/bash
qmake ./kylin-calculator-intel-plug.pro
make clean
make distclean
qmake ./kylin-calculator.pro
make clean
make distclean
rm -rf kylin-calculator.pro.user
rm -rf kylin-calculator-intel-plug.pro.user
