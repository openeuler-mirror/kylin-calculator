# kylin-calculator
kylin-calculator

## dependency
./debian/control

## run
install dependency

./run kylin-calculator
