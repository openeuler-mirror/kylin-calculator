<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>FuncList</name>
    <message>
        <source>Unit converter</source>
        <translation></translation>
    </message>
    <message>
        <source>exchange rate</source>
        <translation>དངུལ་བརྗེས་འཛའ་ཐང་།འཛའ་ཐང་།</translation>
    </message>
    <message>
        <source>standard</source>
        <translation>ཚད་གཞི།</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>རྩིས་ཆས།</translation>
    </message>
    <message>
        <source>scientific</source>
        <translation>ཚན་རིག</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Copy</source>
        <translation>འདྲ་ཕབ།</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>སྦྱར་བ།</translation>
    </message>
    <message>
        <source>input too long</source>
        <translation>ནང་འཇུག་རིང་བ།</translation>
    </message>
    <message>
        <source>exchange rate</source>
        <translation>དངུལ་བརྗེས་འཛའ་ཐང་།འཛའ་ཐང་།</translation>
    </message>
    <message>
        <source>Input error!</source>
        <translation>ནང་འཇུག!</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation>སྐྱོན་ཆ་སཆུགས་ཤིང་ནོར་བ་ནོར་འཁྲུལ་!</translation>
    </message>
    <message>
        <source>standard</source>
        <translation>ཚད་གཞི།</translation>
    </message>
    <message>
        <source>calculator</source>
        <translation>རྩིས་ཆས།རྩིས་རྒྱག་འཕྲུལ་ཆས།</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>རྩིས་ཆས།</translation>
    </message>
    <message>
        <source>scientific</source>
        <translation>ཚན་རིག</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Chinese Yuan</source>
        <translation type="vanished">མི་དམངས</translation>
    </message>
    <message>
        <source>US Dollar</source>
        <translation type="vanished">མེ་སྒོར།</translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <source>Close</source>
        <translation>ཁ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>ཆེས་ཆུང་འགྱུར།</translation>
    </message>
    <message>
        <source>Exchange Rate</source>
        <translation>དངུལ་བརྗེས་འཛའ་ཐང་།འཛའ་ཐང་།</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>ཚད་གཞི།</translation>
    </message>
    <message>
        <source>StayTop</source>
        <translation>རྩེ་མོ།</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>ཚན་རིག</translation>
    </message>
</context>
<context>
    <name>ToolModelOutput</name>
    <message>
        <source>US Dollar</source>
        <translation>མེ་སྒོར།</translation>
    </message>
    <message>
        <source>Rate update</source>
        <translation>དངུལ་བརྗེས་འཛའ་ཐང་།</translation>
    </message>
    <message>
        <source>Chinese Yuan</source>
        <translation>མི་དམངས</translation>
    </message>
</context>
<context>
    <name>UnitListWidget</name>
    <message>
        <source>cancel</source>
        <translation>ལེན་པ།</translation>
    </message>
    <message>
        <source>search</source>
        <translation>བཤེར་འཚོལ།</translation>
    </message>
    <message>
        <source>currency</source>
        <translation>དངོས་རྫས</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <source>Auto</source>
        <translation>རང་འགུལ།</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>ནག</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>རོགས་རམ།</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>འདེམས་བྱང་།</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>ཕྱིར་འདོན་པ།</translation>
    </message>
    <message>
        <source>About</source>
        <translation>འབྲེལ་ཡོད།</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>སྟོན་སྒྲོན།</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>བརྗོད་གཞི།</translation>
    </message>
    <message>
        <source>Exchange Rate</source>
        <translation>དངུལ་བརྗེས་འཛའ་ཐང་།འཛའ་ཐང་།</translation>
    </message>
    <message>
        <source>Service &amp; Support: </source>
        <translation>ཞབས་ཞུ། &amp; ཤོག: </translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>དཔར་གཞི་: </translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>ཚད་གཞི།</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>རྩིས་ཆས།</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>ཚན་རིག</translation>
    </message>
</context>
</TS>
