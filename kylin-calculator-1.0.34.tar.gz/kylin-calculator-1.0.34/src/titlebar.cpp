/*
 * Copyright (C) 2020, KylinSoft Co., Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QEvent>
#include <QMouseEvent>
#include <QApplication>
#include <QStringList>
#include "titlebar.h"
#include "mainwindow.h"
#include "funclist.h"
#include "xatom-helper.h"
#include "InputSymbols.h"
#include "data_warehouse.h"
#include <QColor>
#include <QDesktopWidget>

TitleBar::TitleBar(QWidget *parent) : QWidget(parent)
{
    /* handle intel ui */
    if (DataWarehouse::getInstance()->platform == QString("intel")) {
        createInterUi();
        createInterStyle();
    } else {
        // 初始化组件
        setWidgetUi();
        // 设置组件样式
        setWidgetStyle();
    }
}

TitleBar::~TitleBar()
{

}

/* intel title ui */
void TitleBar::createInterUi()
{
    this->setFixedHeight(38);

    this->STANDARD_LABEL = tr("standard");
    this->SCIENTIFIC_LABEL = tr("scientific");

    this->m_Icon = new QLabel(this);
    this->m_Icon->setFixedSize(QSize(25 , 25));
    this->m_Icon->setPixmap(QIcon::fromTheme("kylin-calculator").pixmap(QSize(24 , 24)));

    this->m_mode = new QPushButton(this);
    this->m_mode->setFixedSize(68 , 35);

    this->m_modeText = new QLabel(this);
    this->m_modeText->setText(tr("standard"));

    this->m_modeIcon = new QLabel(this);
    QPixmap icon(":/image/intelStandLight/ic-open.svg");
    icon.scaled(24 , 24);
    this->m_modeIcon->setPixmap(icon);

    this->m_hlayout1 = new QHBoxLayout();
    this->m_hlayout1->setMargin(0);
    this->m_hlayout1->addStretch(0);
    this->m_hlayout1->addWidget(this->m_modeText);
    this->m_hlayout1->addStretch(0);
    this->m_hlayout1->addWidget(this->m_modeIcon);
    this->m_hlayout1->addStretch(0);

    this->m_mode->setLayout(this->m_hlayout1);
    this->m_mode->setFlat(true);

    this->m_min = new QPushButton();
    this->m_min->setFixedSize(QSize(30 , 30));
    this->m_min->setIcon(QIcon::fromTheme("window-minimize-symbolic"));
    this->m_min->setIconSize(QSize(16 , 16));
    this->m_min->setProperty("isWindowButton", 0x1);
    this->m_min->setProperty("useIconHighlightEffect", 0x2);
    this->m_min->setFlat(true);

    this->m_max = new QPushButton();
    this->m_max->setFixedSize(QSize(30 , 30));
    this->m_max->setIcon(QIcon::fromTheme("window-maximize-symbolic"));
    this->m_max->setIconSize(QSize(16 , 16));
    this->m_max->setProperty("isWindowButton", 0x1);
    this->m_max->setProperty("useIconHighlightEffect", 0x2);
    this->m_max->setFlat(true);

    this->m_close = new QPushButton();
    this->m_close->setFixedSize(QSize(30 , 30));
    this->m_close->setIcon(QIcon::fromTheme("window-close-symbolic"));
    this->m_close->setIconSize(QSize(16 , 16));
    this->m_close->setProperty("isWindowButton", 0x2);
    this->m_close->setProperty("useIconHighlightEffect", 0x8);
    this->m_close->setFlat(true);

    this->hlayout = new QHBoxLayout();
    this->hlayout->setMargin(0);

    this->hlayout->addSpacing(16);
    this->hlayout->addWidget(this->m_Icon);
    this->hlayout->addSpacing(4);

    this->hlayout->addWidget(this->m_mode);
    this->hlayout->addStretch(0);

    this->hlayout->addWidget(this->m_min);
    this->hlayout->addSpacing(4);

    this->hlayout->addWidget(this->m_max);
    this->hlayout->addSpacing(4);

    this->hlayout->addWidget(this->m_close);
    this->hlayout->addSpacing(4);

    connect(this->m_min , &QPushButton::clicked , this , &TitleBar::onClicked);
    connect(this->m_max , &QPushButton::clicked , this ,&TitleBar::onClicked);
    connect(this->m_close , &QPushButton::clicked , this , &TitleBar::onClicked);
    connect(this->m_mode , &QPushButton::clicked , this , &TitleBar::slotModeChange);

    this->setLayout(this->hlayout);

    return;
}

void TitleBar::createInterStyle(void)
{
    QPixmap icon;
    if (WidgetStyle::themeColor == 0) {
        this->m_mode->setStyleSheet("QPushButton::menu-indicator{image:None;}");
        this->m_mode->setStyleSheet("QPushButton{border-radius:12px;}"
                                    "QPushButton:hover{background-color:#FFFFFF;}"
                                    "QPushButton:pressed{background-color:#FFFFFF;}");
        icon.load(":/image/intelStandLight/ic-open.svg");
        icon.scaled(24 , 24);
        m_modeIcon->setPixmap(icon);
    }
    else if (WidgetStyle::themeColor == 1) {
        this->m_mode->setStyleSheet("QPushButton::menu-indicator{image:None;}");
        this->m_mode->setStyleSheet("QPushButton{border-radius:12px;}"
                                    "QPushButton:hover{background-color:#FFFFFF;}"
                                    "QPushButton:pressed{background-color:#FFFFFF;}");
        icon.load(":/image/intelStandDark/ic-open.svg");
        icon.scaled(24 , 24);
        m_modeIcon->setPixmap(icon);
    }
}

void TitleBar::slotModeChange()
{
    if (!this->m_modeList->isVisible()) {
        QPoint pos = this->m_mode->pos();
        this->m_modeList->move(pos.x() , pos.y() + 40);
        this->m_modeList->show();
        this->m_modeList->raise();

        this->changeModeIcon();
    } else {
        this->m_modeList->hide();

        this->changeModeIcon();
    }

    return;
}

void TitleBar::changeModeIcon(void)
{
    QPixmap icon;

    if (this->m_modeList->isVisible()) {
        if (WidgetStyle::themeColor == 0) {
            icon.load(":/image/intelStandLight/ic-close.svg");
            icon.scaled(24 , 24);
        } else {
            icon.load(":/image/intelStandDark/ic-close.svg");
            icon.scaled(24 , 24);
        }

        this->m_modeIcon->setPixmap(icon);

    } else {
        if (WidgetStyle::themeColor == 0) {
            icon.load(":/image/intelStandLight/ic-open.svg");
            icon.scaled(24 , 24);
        } else {
            icon.load(":/image/intelStandDark/ic-open.svg");
            icon.scaled(24 , 24);
        }

        this->m_modeIcon->setPixmap(icon);
    }

    return;
}

void TitleBar::slotChangeStandard(void)
{
    qDebug() << "Info : change mode to standard";
    this->m_modeText->setText(tr("standard"));
    emit sigModeChange(QString("standard"));

    this->m_modeList->hide();
    this->changeModeIcon();

    return;
}

void TitleBar::slotChangeScientific(void)
{
    qDebug() << "Info : change mode to scientific";
    this->m_modeText->setText(tr("scientific"));
    emit sigModeChange(QString("scientific"));

    this->m_modeList->hide();
    this->changeModeIcon();

    return;
}

void TitleBar::setFuncLabel(QString label)
{
    this->m_pFuncLabel->setText(label);
}

// 初始化组件
void TitleBar::setWidgetUi()
{
    this->setFixedHeight(38);

    // 初始化模式或功能名称
    STANDARD_LABEL = tr("Standard");
    SCIENTIFIC_LABEL = tr("Scientific");
    EXCHANGE_RATE_LABEL = tr("Exchange Rate");

    // 按钮初始化
    m_pIconBtn   = new QPushButton(this);
    m_pFuncLabel = new QLabel(this);
    m_pTopButton = new QPushButton(this);
    m_pMinimizeButton = new QPushButton(this);
    m_pMaximizeButton = new QPushButton(this);
    m_pCloseButton = new QPushButton(this);

    // 设置空间大小
    m_pFuncLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    m_pTopButton->setFixedSize(30, 30);
    m_pMinimizeButton->setFixedSize(30, 30);
    m_pMaximizeButton->setFixedSize(30, 30);
    m_pCloseButton->setFixedSize(30, 30);
    
    // 设置对象名
    m_pFuncLabel->setObjectName("whiteLabel");
    m_pTopButton->setObjectName("topButton");
    m_pMinimizeButton->setObjectName("minimizeButton");
    m_pMaximizeButton->setObjectName("maximizeButton");
    m_pCloseButton->setObjectName("closeButton");

    // 设置悬浮提示
    m_pTopButton->setToolTip(tr("StayTop"));
    m_pMinimizeButton->setToolTip(tr("Minimize"));
    m_pMaximizeButton->setToolTip(tr("Maximize"));
    m_pCloseButton->setToolTip(tr("Close"));

    // 设置图片
    m_pIconBtn->setIconSize(QSize(24, 24));
    m_pIconBtn->setIcon(QIcon::fromTheme("kylin-calculator"));

    m_pTopButton->setIcon(QIcon::fromTheme("ukui-unfixed"));
    m_pTopButton->setIconSize(QSize(16, 16));
    m_pTopButton->setProperty("isWindowButton", 0x1);
    m_pTopButton->setProperty("useIconHighlightEffect", 0x2);
    m_pTopButton->setFlat(true);

    m_pMinimizeButton->setIcon(QIcon::fromTheme("window-minimize-symbolic"));
    m_pMinimizeButton->setIconSize(QSize(16, 16));
    m_pMinimizeButton->setProperty("isWindowButton", 0x1);
    m_pMinimizeButton->setProperty("useIconHighlightEffect", 0x2);
    m_pMinimizeButton->setFlat(true);

    m_pMaximizeButton->setIcon(QIcon::fromTheme("window-maximize-symbolic"));
    m_pMaximizeButton->setIconSize(QSize(16, 16));
    m_pMaximizeButton->setProperty("isWindowButton", 0x1);
    m_pMaximizeButton->setProperty("useIconHighlightEffect", 0x2);
    m_pMaximizeButton->setFlat(true);


    m_pCloseButton->setIcon(QIcon::fromTheme("window-close-symbolic"));
    m_pCloseButton->setIconSize (QSize(16, 16));
    m_pCloseButton->setProperty("isWindowButton", 0x2);
    m_pCloseButton->setProperty("useIconHighlightEffect", 0x8);
    m_pCloseButton->setFlat(true);

    menuBar = new menuModule(this);
    
    // 设置按钮布局
    QHBoxLayout *pLayout = new QHBoxLayout(this);
    pLayout->setContentsMargins(4, 4, 4, 4);
    pLayout->setSpacing(0);
    // 这里是有问题的 应该是pLayout->addSpacing(4);但是还不知道是哪里的问题
    pLayout->addSpacing(2);
    pLayout->addWidget(m_pIconBtn);
    pLayout->addSpacing(8);
    pLayout->addWidget(m_pFuncLabel);
    pLayout->addStretch();
    pLayout->addWidget(m_pTopButton);
    pLayout->addSpacing(4);
    pLayout->addWidget(menuBar->menuButton);
    pLayout->addSpacing(4);
    pLayout->addWidget(m_pMinimizeButton);
    pLayout->addSpacing(4);
    pLayout->addWidget(m_pMaximizeButton);
    pLayout->addSpacing(4);
    pLayout->addWidget(m_pCloseButton);

    /* 主线版本 放大功能暂时不上  , 暂时隐藏按钮 */
    this->m_pMaximizeButton->hide();

    this->setLayout(pLayout);

    // 设置信号和槽函数
    connect(m_pMinimizeButton, SIGNAL(clicked(bool)), this, SLOT(onClicked()));
    connect(m_pMaximizeButton, SIGNAL(clicked(bool)), this, SLOT(onClicked()));
    connect(m_pCloseButton,    SIGNAL(clicked(bool)), this, SLOT(onClicked()));

    return;
}

// 设置组件样式
void TitleBar::setWidgetStyle()
{
    if (WidgetStyle::themeColor == 0) {
        m_pFuncLabel->setStyleSheet("color:#000000;font-size:14px;");
        QString btnStyle = "QPushButton{border:0px;border-radius:4px;background:transparent;}"
                           "QPushButton:Hover{border:0px;border-radius:4px;background:transparent;}"
                           "QPushButton:Pressed{border:0px;border-radius:4px;background:transparent;}";
        m_pIconBtn->setStyleSheet(btnStyle);
    }
    else if (WidgetStyle::themeColor == 1) {
        m_pFuncLabel->setStyleSheet("color:#A6A6A6;font-size:14px;");
        QString btnStyle = "QPushButton{border:0px;border-radius:4px;background:transparent;}"
                           "QPushButton:Hover{border:0px;border-radius:4px;background:transparent;}"
                           "QPushButton:Pressed{border:0px;border-radius:4px;background:transparent;}";
        m_pIconBtn->setStyleSheet(btnStyle);
    }
}

void TitleBar::onClicked()
{
    QPushButton *pButton = qobject_cast<QPushButton *>(sender());
    QWidget *pWindow = this->window();
    if (pWindow->isTopLevel())
    {
        if (pButton == m_pMinimizeButton)
        {
            pWindow->showMinimized();
            m_pMinimizeButton->update();
            m_pCloseButton->update();
        } else if (pButton == m_pCloseButton) {
            pWindow->close();
        } else if (pButton == this->m_min) {
            pWindow->showMinimized();
            m_min->update();
            m_close->update();
        } else if(pButton == this->m_max) {
            if (DataWarehouse::getInstance()->winFlag == QString("min")) {
                DataWarehouse::getInstance()->winFlag = QString("max");
            } else if (DataWarehouse::getInstance()->winFlag == QString("max")) {
                DataWarehouse::getInstance()->winFlag = QString("min");
            }

            if(DataWarehouse::getInstance()->winFlag == QString("min")){
                pWindow->showNormal();
                pWindow->resize(1200,625);
                pWindow->move(m_start.x(),m_start.y());
                this->m_max->setIcon(QIcon::fromTheme("window-maximize-symbolic"));
            } else {
                m_start =  pWindow->pos();
                pWindow->showMaximized();
                this->m_max->setIcon(QIcon::fromTheme("window-restore-symbolic"));
            }
            emit sigFontUpdate();
        } else if(pButton == m_pMaximizeButton) {
            if (DataWarehouse::getInstance()->winFlag == QString("min")) {
                DataWarehouse::getInstance()->winFlag = QString("max");
            } else if (DataWarehouse::getInstance()->winFlag == QString("max")) {
                DataWarehouse::getInstance()->winFlag = QString("min");
            }

            if(DataWarehouse::getInstance()->winFlag == QString("min")){
                pWindow->showNormal();
                if (m_pFuncLabel->text() == STANDARD_LABEL) {
                    pWindow->resize(432,628);
                    pWindow->move(m_start.x(),m_start.y());

                } else if(m_pFuncLabel->text() == SCIENTIFIC_LABEL) {
                    pWindow->resize(864,628);
                    pWindow->move(m_start.x(),m_start.y());

                } else if(m_pFuncLabel->text() == EXCHANGE_RATE_LABEL) {
                    pWindow->resize(432,628);
                    pWindow->move(m_start.x(),m_start.y());
                }
            } else {
                m_start =  pWindow->pos();
                pWindow->showMaximized();
            }
            emit sigFontUpdate();
        } else if (pButton == this->m_close) {
            pWindow->close();
        }
    }
}
