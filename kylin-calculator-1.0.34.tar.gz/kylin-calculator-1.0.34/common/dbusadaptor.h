#ifndef DBUSADAPTOR_H
#define DBUSADAPTOR_H

#define KYLIN_CALCULATOR_PATH "/"
#define KYLIN_CALCULATOR_SERVICE "com.kylin.calculator"
#define KYLIN_CALCULATOR_INTERFACE "com.kylin.calculator"

#include <QObject>
#include <QApplication>
#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusError>

#include "../src/mainwindow.h"

class DbusAdaptor: public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface" , KYLIN_CALCULATOR_SERVICE)

public:
    DbusAdaptor(QObject *parent = 0);
    virtual ~DbusAdaptor();

public slots:
    /* 显示应用主界面 */
    void showMainWindow();
};

#endif
