#include "dbusadaptor.h"

DbusAdaptor::DbusAdaptor(QObject *parent) : QObject(parent)
{
    QDBusConnection connection = QDBusConnection::sessionBus();
    if (!connection.registerService(KYLIN_CALCULATOR_SERVICE)) {
        return ;
    }
    connection.registerObject(KYLIN_CALCULATOR_PATH , this , QDBusConnection::ExportAllSlots);
}

DbusAdaptor::~DbusAdaptor()
{

}

/* 显示应用主界面 */
void DbusAdaptor::showMainWindow()
{
    MainWindow::getInstance()->pullUpWindow();

    return;
}

